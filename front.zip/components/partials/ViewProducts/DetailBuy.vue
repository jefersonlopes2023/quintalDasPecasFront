<template>
    <div class="ui-box-component ui-box-component-pdp__visible--desktop">
      <h2 class="ui-box-component__title">Meios de pagamento</h2>
        <div class="ui-vip-payment_methods">
            <div class="ui-pdp-action-modal">
                <div class="andes-tooltip__trigger">
                    <a class="ui-pdp-action-modal__link" >
                        <div class="ui-pdp-media ui-vip-payment_methods__container ui-pdp-background-color--GREEN ui-pdp-color--WHITE">
                            <figure aria-hidden="true" class="ui-pdp-media__figure">
                                <svg class="ui-pdp-icon ui-pdp-icon--installments ui-pdp-color--CARD ui-pdp-color--WHITE ui-vip-payment_methods__card"
                                    width="20" height="20" viewBox="0 0 20 20"
                                    xmlns="http://www.w3.org/2000/svg">
                                <use href="#card"></use>
                                </svg>
                            </figure>
                            <div class="ui-pdp-media__body">
                                <p class="ui-pdp-color--WHITE ui-pdp-family--REGULAR ui-pdp-media__title">Pague em <span class="ui-pdp-color--WHITE ui-pdp-family--SEMIBOLD">até 12X sem juros</span>!</p>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
                <p class="ui-pdp-family--REGULAR ui-vip-payment_methods__title">Até 12x sem cartão de crédito</p>
            <div class="ui-pdp-payment-icon">
                <div class="ui-pdp-payment-icon__container">
                    <div class="ui-pdp-payment-icon__size">
                        <img decoding="async" src="https://http2.mlstatic.com/storage/logos-api-admin/51b446b0-571c-11e8-9a2d-4b2bd7b1bf77-m.svg" class="ui-pdp-image ui-pdp-payment-icon" alt="Mercado Crédito">
                    </div>
                </div>
            </div>
                <p class="ui-pdp-family--REGULAR ui-vip-payment_methods__title">Cartões de crédito</p>
            <div class="ui-pdp-payment-icon">
                <div class="ui-pdp-payment-icon__container">
                    <div class="ui-pdp-payment-icon__size">
                        <img decoding="async" src="https://http2.mlstatic.com/storage/logos-api-admin/a5f047d0-9be0-11ec-aad4-c3381f368aaf-m.svg" class="ui-pdp-image ui-pdp-payment-icon" alt="Visa">
                    </div>
                </div>
                <div class="ui-pdp-payment-icon__container">
                    <div class="ui-pdp-payment-icon__size">
                        <img decoding="async" src="https://http2.mlstatic.com/storage/logos-api-admin/aa2b8f70-5c85-11ec-ae75-df2bef173be2-m.svg" class="ui-pdp-image ui-pdp-payment-icon" alt="Mastercard">
                    </div>
                </div>
                <div class="ui-pdp-payment-icon__container">
                    <div class="ui-pdp-payment-icon__size">
                        <img decoding="async" src="https://http2.mlstatic.com/storage/logos-api-admin/ddf23a60-f3bd-11eb-a186-1134488bf456-m.svg" class="ui-pdp-image ui-pdp-payment-icon" alt="Hipercard">
                    </div>
                </div>
                <div class="ui-pdp-payment-icon__container">
                    <div class="ui-pdp-payment-icon__size">
                        <img decoding="async" src="https://http2.mlstatic.com/storage/logos-api-admin/ed8d6fd0-f3bd-11eb-9984-b7076edb0bb7-m.svg" class="ui-pdp-image ui-pdp-payment-icon" alt="Elo">
                    </div>
                </div>
            </div>
                <p class="ui-pdp-family--REGULAR ui-vip-payment_methods__title">Cartões de débito</p>
            <div class="ui-pdp-payment-icon">
                <div class="ui-pdp-payment-icon__container">
                    <div class="ui-pdp-payment-icon__size">
                        <img decoding="async" src="https://http2.mlstatic.com/storage/logos-api-admin/d2407420-f3bd-11eb-8e0d-6f4af49bf82e-m.svg" class="ui-pdp-image ui-pdp-payment-icon" alt="Caixa">
                    </div>
                </div>
            </div>
                <p class="ui-pdp-family--REGULAR ui-vip-payment_methods__title">Boleto bancário</p>
            <div class="ui-pdp-payment-icon">
                <div class="ui-pdp-payment-icon__container">
                    <div class="ui-pdp-payment-icon__size">
                        <img decoding="async" src="https://http2.mlstatic.com/storage/logos-api-admin/00174300-571e-11e8-8364-bff51f08d440-m.svg" class="ui-pdp-image ui-pdp-payment-icon" alt="Boleto">
                    </div>
                </div>
            </div>
        </div>
        <div class="ui-pdp-action-modal ui-box-component__action">
            <div class="andes-tooltip__trigger">
                <a class="ui-pdp-action-modal__link" >Conheça outros meios de pagamento</a>
            </div>
        </div>
    </div>
</template>