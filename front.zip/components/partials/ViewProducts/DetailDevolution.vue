<template>
    <div class="ui-pdp-container__row ui-pdp-container__row--returns-box" id="returns_box">
        <div class="ui-box-component ui-box-component-pdp__visible--desktop">
          <h2 class="ui-box-component__title">Devolução grátis</h2>
            <div class="ui-vpp-box">
                <div class="ui-vpp-box__item">
                    <p class="ui-pdp-color--GRAY ui-pdp-family--REGULAR ui-vpp-box__item__subtitle">Você tem 30 dias a partir do recebimento do produto para devolvê-lo, não importa o motivo!</p>
                </div>
            </div>
            <div class="ui-pdp-action-modal ui-box-component__action">
                <div class="andes-tooltip__trigger">
                    <a class="ui-pdp-action-modal__link" >Ver mais sobre devoluções</a>
                </div>
            </div>
        </div>
    </div>
</template>