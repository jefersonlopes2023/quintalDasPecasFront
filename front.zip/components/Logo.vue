<template>
     <div class="nav-header-plus-logo nav-area nav-top-area nav-left-area">
        <a id="nav-skip-to-main-content" role="button"  class="nav-skip-to-main-content" aria-label="Ir para conteúdo principal">
            <span class="nav-skip-to-main-content__content">
                Ir para conteúdo principal
            </span>
        </a>
        <a class="nav-logo" >
            Mercado Livre Brasil - Onde comprar e vender de Tudo
        </a>
    </div>
</template>