<template>   
    <form class="nav-search" action="#" method="GET" role="search">
        <label class="nav-header-visually-hidden" for="nav-search-input">
            Digite o que você quer encontraraaaaaaaaaaaaaaaaaaaaaa
        </label>
        <input type="text" class="nav-search-input" id="nav-search-input" aria-label="Digite o que você quer encontrar" name="as_word" placeholder="Buscar produtosaaaaaaaaaaaa, marcas e muito mais…" maxLength="120" autofocus="" autoCapitalize="off" autoCorrect="off" spellcheck="false" autoComplete="off" value="" />
        <button type="submit" class="nav-search-btn">
            <div role="img" aria-label="Buscar" class="nav-icon-search"></div>
        </button>
    </form>     
</template>