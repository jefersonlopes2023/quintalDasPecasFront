<template>
    <PartialsProductsSearchProducts />
</template>