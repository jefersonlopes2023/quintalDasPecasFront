<template>
   <main role="main" id="root-app">
        <div data-testid="page:Privacy" class="sc-GVOUr bmroxJ">
            <div id="header" data-testid="component:Header" class="sc-iqcoie goxPrb">
                <h1 class="sc-crXcEl ipUDtJ">Contato</h1>
            </div>
        </div>
    </main>
</template>