<template>
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <main role="main" id="root-app">
                <div class="cx-peach-layout layout-portal newSearch">
                    <div class="cx-peach-layout__wrapper cx-peach-layout__portal">
                        <div class="portal-content faq-wrapper">
                            <!-- <div class="cx-breadcrumb__wrapper">
                                <nav aria-label="lista de páginas">
                                    <ol class="andes-breadcrumb breadcrumb">
                                        <li class="andes-breadcrumb__item"><a class="andes-breadcrumb__link">Ajuda</a>
                                            <div class="andes-breadcrumb__chevron" aria-hidden="true">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="6" height="8">
                                                    <p class="pharagraphTerm"  ath fill="none" stroke="#666" d="M1 0l4 4-4 4"> </p>
                                                <path></path>
                                                </svg>
                                            </div>
                                        </li>
                                        <li class="andes-breadcrumb__item">
                                            <span class="andes-breadcrumb__label" aria-current="page">Termos e condições gerais de uso do site</span>
                                        </li>
                                    </ol>
                                </nav>
                            </div> -->
                            <div class="cx-peach-content cx-main--MLB">
                                <!-- <div class="cx-search__input--container">
                                    <div aria-owns="cb1-listbox" class="cx-search-box">
                                        <div class="andes-form-control andes-form-control--textfield andes-form-control--default cx-input-search">
                                            <label>
                                                <span class="andes-visually-hidden">Buscar em Contato</span>
                                                <div class="andes-form-control__control">
                                                    <input 
                                                        role="combobox" value=""
                                                        aria-activedescendant="" aria-controls="cb2-listbox" aria-expanded="false" aria-describedby=" "
                                                        rows="1" class="andes-form-control__field" maxlength="120" placeholder="Buscar em Contato" id="cb1-listbox" >
                                                </div>
                                            </label>
                                            <div class="andes-form-control__bottom">
                                                <span id="cb1-listbox-message" class="andes-form-control__message"></span>
                                            </div>
                                        </div>
                                        <button type="button" class="andes-button cx-search-button andes-button--large andes-button--quiet andes-button--disabled">
                                            <span class="andes-button__content">Buscar</span>
                                        </button>
                                    </div>
                                </div> -->
                                <div class="l">
                                    <h1 class=" titleTerm" tabindex="0">Termos e condições gerais de uso do site</h1>
                                </div>
                                <div class="cx-peach-content__data">
                                    <div class="card">
                                        <div class="cx-peach-content__show">
                                            <div class="col-lg-4 col-md-4 col-sm-4 col-4">
                                                <h1 class="buttonTerm">
                                                    <a href="/">Voltar à Tela Inicial</a> 
                                                </h1>
                                            </div>
                                            <p class="pharagraphTerm"   tabindex="0" role="paragraph">Última modificação: 7 de fevereiro, 2023</p>
                                            <p class="pharagraphTerm"   tabindex="0" role="paragraph">
                                                <strong>Resumo dos Termos e condições</strong>
                                            </p>
                                            <p class="pharagraphTerm"   tabindex="0" role="paragraph">
                                                O Mercado Livre é uma empresa de tecnologia e oferece
                                                serviços relacionados, principalmente, com&nbsp; comércio eletrônico e pagamentos
                                                digitais.
                                            </p>
                                            <ul class="pharagraphTerm"   tabindex="0" role="list">
                                                <li aria-level="1">
                                                    O Marketplace é uma plataforma de comércio eletrônico onde as
                                                    Pessoas Usuárias podem vender e comprar produtos usando diferentes soluções de
                                                    pagamento e envio.
                                                </li>
                                                <li aria-level="1">
                                                    No Marketplace VIS, conectamos pessoas interessadas em fazer
                                                    transações com veículos, imóveis e serviços com possívels vendedores.
                                                </li>
                                                <li aria-level="1">
                                                    O Mercado Pago é uma plataforma de pagamentos e recebimento, que
                                                    pode ser usada para transações dentro e fora do Marketplace.
                                                </li>
                                                <li aria-level="1">
                                                    O Mercado Envios é a ferramenta tecnológica que oferecemos para
                                                    que as Pessoas Usuárias possam enviar e receber as compras feitas nos sites ou
                                                    aplicativos que utilizam a tecnologia do Mercado Livre.
                                                </li>
                                                <li aria-level="1">
                                                    Além disso, oferecemos outros serviços, como Mercado Shops,
                                                    Mercado Ads, Mercado Crédito, entre outros, e todos com o mesmo objetivo:
                                                    democratizar o comércio e os serviços financeiros na região.&nbsp;
                                                </li>
                                            </ul>
                                            <p class="pharagraphTerm"   tabindex="0" role="paragraph">
                                                Para operar na plataforma, todas as Pessoas Usuárias
                                                devem aceitar os Termos e Condições, os anexos e a Declaração de Privacidade.
                                            </p>
                                            <p class="pharagraphTerm"   tabindex="0" role="paragraph">
                                                Cada Pessoa Usuária é responsável pelos dados pessoais
                                                fornecidos no momento do cadastro e se compromete a mantê-los atualizados. Além
                                                disso, a Pessoa Usuária é a única responsável pelo uso e proteção da sua
                                                senha.&nbsp;
                                            </p>
                                            <p class="pharagraphTerm"   tabindex="0" role="paragraph">
                                                Em alguns casos, poderemos cobrar uma tarifa pelo uso
                                                dos serviços que integram o ecossistema do Mercado Livre, sendo que a Pessoa Usuária
                                                desde já se compromete a pagá-la.
                                            </p>
                                            <h2 class="termAndCondition" tabindex="0" role="heading">Termos e condições gerais de uso do site</h2>
                                            <h2 class="termAndCondition" tabindex="0" role="heading">1- Mercado Livre</h2>
                                            <p class="pharagraphTerm"   tabindex="0" role="paragraph">O Mercado Livre é uma empresa de tecnologia que oferece
                                                serviços ligados principalmente ao comércio eletrônico e aos pagamentos
                                                digitais.&nbsp;</p>
                                            <p class="pharagraphTerm"   tabindex="0" role="paragraph">
                                                Os serviços oferecidos pelo Mercado Livre nos sites 
                                                <a href="http://www.mercadolivre.com.br" target="_blank" rel="noopener">
                                                    www.mercadolivre.com.br
                                                </a> e&nbsp;
                                                <a href="https://www.mercadopago.com.br" target="_blank" rel="noopener">
                                                    www.mercadopago.com.br
                                                </a> 
                                                e seus aplicativos móveis (doravante designado o “Site”) foram projetados para formar um ecossistema que permita que as
                                                pessoas vendam, comprem, paguem, enviem produtos e realizem outras atividades comerciais com tecnologia aplicada (doravante designado o “Ecossistema MELI”).
                                            </p>
                                            <h2 class="termAndCondition" tabindex="0" role="heading">
                                                <strong>2- Termos e condições<br></strong>
                                            </h2>
                                            <p class="pharagraphTerm"   tabindex="0" role="paragraph">
                                                Estes termos e condições e os anexos que explicam os
                                                serviços do Ecossistema MELI (doravante designados os “Termos e Condições”) regulam
                                                a relação entre o Mercado Livre e as pessoas que usam seus serviços (doravante
                                                designadas as “Pessoas Usuárias”).&nbsp;
                                            </p>
                                            <p class="pharagraphTerm"   tabindex="0" role="paragraph">
                                                As Pessoas Usuárias aceitam estes Termos e Condições a
                                                partir do momento em que se registram no Site e usam o Ecossistema MELI.
                                            </p>
                                            <p class="pharagraphTerm"   tabindex="0" role="paragraph">
                                                Quando devermos fazer mudanças importantes em nossos
                                                serviços, publicaremos as modificações com 10 dias corridos de antecedência para que
                                                as Pessoas Usuárias possam revisá-las e continuar usando o Ecossistema MELI. Em
                                                nenhum caso afetarão as operações que já tenham finalizado.
                                            </p>
                                            <p class="pharagraphTerm"   tabindex="0" role="paragraph">
                                                As Pessoas Usuárias que não tenham obrigações pendentes
                                                com o Mercado Livre ou com outras Pessoas Usuárias poderão finalizar a relação com o
                                                Mercado Livre cancelando sua conta.
                                            </p>
                                            <h2 class="termAndCondition" tabindex="0" role="heading">3- Capacidade</h2>
                                            <p class="pharagraphTerm"   tabindex="0" role="paragraph">
                                                As pessoas maiores de idade com capacidade legal para
                                                contratar poderão utilizar nossos serviços. Os menores de idade, a partir dos 13
                                                anos, só poderão utilizar sua conta com autorização do representante legal, que
                                                responderá por todas as ações e obrigações decorrentes da utilização dessa conta e
                                                que deverá zelar pelo uso responsável e adequado dela em atenção à maturidade do
                                                menor que autorize.
                                            </p>
                                            <p class="pharagraphTerm"   tabindex="0" role="paragraph">
                                                Quem usar o Ecossistema MELI em representação de uma
                                                empresa deverá ter capacidade para contratar em nome dela. Além disso, para poder
                                                usar a conta, a Pessoa Usuária deve estar ativa.&nbsp;
                                            </p>
                                            <h2 class="termAndCondition" tabindex="0" role="heading">4- Registro e conta</h2>
                                            <p class="pharagraphTerm"   tabindex="0" role="paragraph">
                                                Quem quiser usar nossos serviços, deverá preencher o
                                                formulário de registro com os dados que lhe forem requeridos. Ao completá-lo,
                                                concorda em fazê-lo de forma exata, precisa e verdadeira e manter seus dados sempre
                                                atualizados. A Pessoa Usuária será a única responsável pela certeza dos dados de
                                                registro. Sem prejuízo das informações fornecidas no formulário, poderemos solicitar
                                                e/ou consultar informações adicionais para verificar a identidade da Pessoa
                                                Usuária.&nbsp;
                                            </p>
                                            <p class="pharagraphTerm"   tabindex="0" role="paragraph">
                                                A conta é pessoal, única e intransferível, ou seja, em
                                                nenhuma circunstância poderá ser vendida ou transferida para outra pessoa. A conta é
                                                acessada com a senha pessoal de segurança escolhida e deverá ser mantida sob estrita
                                                confidencialidade. A Pessoa Usuária poderá criar 
                                                <a href="#25781" target="_self">
                                                    Contas Colaboradoras
                                                </a> 
                                                e definir as permissões de acesso. Em
                                                qualquer caso, a Pessoa Usuária será sempre a única responsável pelas
                                                operações&nbsp; realizadas na sua conta. Caso a Pessoa Usuária identifique o uso não
                                                autorizado de sua conta, ela deverá notificar imediatamente o Mercado Livre.
                                            </p>
                                            <p class="pharagraphTerm"   tabindex="0" role="paragraph">
                                                Caso a Pessoa Usuária também possua uma conta ativa no
                                                Mercado Pago, é possível utilizar os mesmos dados de acesso e senha para acessar
                                                tanto a Conta do Mercado Pago quanto a conta no Mercado Livre. A utilização de
                                                mesmos dados de acesso não implica em abertura automática de conta, seja no Mercado
                                                Livre, seja no Mercado Pago; devendo a Pessoa Usuária observar as regras de abertura
                                                de conta de cada plataforma, conforme determinado nos respectivos Termos e Condições
                                                e legislação vigente.
                                            </p>
                                            <p class="pharagraphTerm"   tabindex="0" role="paragraph">
                                                Poderemos rejeitar um pedido de registro ou cancelar um
                                                registro já aceite, sem que isso gere direito a uma indenização. Não poderão se
                                                registrar novamente no site as Pessoas Usuárias que tenham sido desativadas
                                                previamente. Também não poderão se registrar aqueles que estejam incluídos ou
                                                relacionados com pessoas que apareçam em listas nacionais ou internacionais de
                                                sanções. 
                                                <a target="_self">Saiba mais.</a>&nbsp;
                                            </p>
                                            <p class="pharagraphTerm"   tabindex="0" role="paragraph">
                                                Além disso, no caso de detectar o uso de mais de uma
                                                conta, poderemos aplicar retenções, débitos e/ou qualquer outra medida se
                                                considerarmos que essa ação pode prejudicar o resto das pessoas que usam o Site ou o
                                                Mercado Livre, além das sanções que possam corresponder.&nbsp;
                                            </p>
                                            <p class="pharagraphTerm"   tabindex="0" role="paragraph">
                                                Ao se cadastrar no Mercado Livre, o Usuário poderá
                                                optar, a seu exclusivo critério, pela utilização de todos os serviços
                                                disponibilizados pelas empresas do grupo. Para fins de clareza, ao se cadastrar no
                                                Mercado Livre, o Usuário não será automaticamente cadastrado nos demais serviços
                                                disponibilizados pelas empresas do grupo.
                                            </p>
                                            <p class="pharagraphTerm"   tabindex="0" role="paragraph">
                                                O Mercado Livre poderá, ainda, entrar em contato com os
                                                usuários por chat, e-mail, Whastapp ou mesmo ligação telefônica para perguntar sobre
                                                a experiência na plataforma e oferecer consultoria.
                                            </p>
                                            <h2 class="termAndCondition" tabindex="0" role="heading">5- Privacidade de dados</h2>
                                            <p class="pharagraphTerm"   tabindex="0" role="paragraph">
                                                No Mercado Livre fazemos uso responsável das
                                                informações pessoais, protegendo a privacidade das Pessoas Usuárias que nos
                                                confiaram seus dados e tomando as medidas necessárias para garantir a segurança em
                                                nosso Ecossistema MELI. 
                                                <a href="#Pol%C3%ADticas-de-Privacidade_1442" target="_blank" rel="noopener">
                                                    Saiba mais sobre nossa Declaração deprivacidade</a>.
                                                </p>
                                            <h2 class="termAndCondition" tabindex="0" role="heading">6-Acesso a outras informações comerciais</h2>
                                            <p class="pharagraphTerm"   tabindex="0" role="paragraph">
                                                Além do disposto nas seções anteriores, o Mercado Livre
                                                oferece ferramentas, aplicações e serviços com base em outras informações comerciais
                                                fornecidas pelos Usuários e/ou geradas ao usar os serviços do Ecossistema MELI, para
                                                ajudar os Vendedores a otimizarem suas vendas, elevar os volumes e gerenciar seus
                                                negócios. Além disso, é possível usá-las para oferecer aos Usuários promoções,
                                                produtos e serviços de outras empresas ou de marcas compartilhadas. Saiba mais sobre
                                                nossa política de 
                                                <a href="#28901" target="_blank" rel="noopener"> Acesso à Informação</a>.
                                            </p>
                                            <h2 class="termAndCondition" tabindex="0" role="heading">7- Sanções</h2>
                                            <p class="pharagraphTerm"   tabindex="0" role="paragraph">
                                                Caso a Pessoa Usuária viole uma lei ou os Termos e
                                                Condições, poderemos avisar, suspender, restringir ou desativar temporariamente ou
                                                definitivamente sua conta, sem prejuízo de outras sanções que se estabeleçam nas
                                                regras de uso particulares dos serviços do Mercado Livre.&nbsp;
                                            </p>
                                            <h2 class="termAndCondition" tabindex="0" role="heading">8- Responsabilidade</h2>
                                            <p class="pharagraphTerm"   tabindex="0" role="paragraph">
                                                O Mercado Livre será responsável por qualquer defeito
                                                na prestação de seu serviço, na medida em que lhe seja imputável e com o alcance
                                                previsto nas leis vigentes.&nbsp;
                                            </p>
                                            <h2 class="termAndCondition" tabindex="0" role="heading">9- Tarifas</h2>
                                            <p class="pharagraphTerm"   tabindex="0" role="paragraph">
                                                O Mercado Livre poderá cobrar tarifas por seus
                                                serviços, e a Pessoa Usuária se compromete a pagá-las a tempo.&nbsp;
                                            </p>
                                            <p class="pharagraphTerm"   tabindex="0" role="paragraph">
                                                Poderemos modificar ou eliminar as tarifas a qualquer
                                                momento com o devido pré-aviso estabelecido na cláusula 2 destes Termos e Condições.
                                                Da mesma forma, poderemos modificar as tarifas temporariamente por promoções em
                                                favor das Pessoas Usuárias.&nbsp;
                                            </p>
                                            <p class="pharagraphTerm"   tabindex="0" role="paragraph">
                                                A Pessoa Usuária autoriza o Mercado Livre a reter e/ou
                                                debitar os fundos existentes e/ou futuros de sua conta Mercado Pago e/ou das contas
                                                bancárias que tenha registado nela, para saldar as tarifas não pagas ou qualquer
                                                outra dívida que possa ter.&nbsp;
                                            </p>
                                            <p class="pharagraphTerm"   tabindex="0" role="paragraph">
                                                Para conhecer o detalhe das tarifas de cada serviço, as
                                                Pessoas Usuárias deverão consultar os termos e condições correspondentes.&nbsp;
                                            </p>
                                            <p class="pharagraphTerm"   tabindex="0" role="paragraph">
                                                Em todos os casos, a fatura será emitida de acordo com
                                                os dados fiscais que as pessoas tenham carregados em sua conta.&nbsp;
                                            </p>
                                            <h2 class="termAndCondition" tabindex="0" role="heading">10- Propriedade intelectual</h2>
                                            <p class="pharagraphTerm"   tabindex="0" role="paragraph">
                                                O Mercado Livre e/ou suas sociedades relacionadas são
                                                proprietárias de todos os direitos de propriedade intelectual sobre seus sites, todo
                                                seu conteúdo, serviços, produtos, marcas, nomes comerciais, logotipos, desenhos,
                                                imagens, frases publicitárias, direitos autorais, domínios, programas de computação,
                                                códigos, desenvolvimentos, software, bancos de dados, informações, tecnologia,
                                                patentes e modelos de utilidade, desenhos e modelos industriais, segredos
                                                comerciais, entre outros (doravante designada a “Propriedade Intelectual”), que
                                                estão protegidos por leis nacionais e internacionais.
                                            </p>
                                            <p class="pharagraphTerm"   tabindex="0" role="paragraph">
                                                Embora o Mercado Livre conceda permissão para usar seus
                                                produtos e serviços conforme previsto nos Termos e Condições, isso não implica uma
                                                autorização para usar sua Propriedade Intelectual, exceto consentimento prévio e
                                                expresso do Mercado Livre e/ou suas sociedades relacionadas. Em qualquer caso, os
                                                usuários vendedores que utilizem esses produtos e serviços não poderão utilizar a
                                                Propriedade Intelectual do Mercado Livre de uma forma que cause confusão no público,
                                                e deverão realizar sua atividade comercial sob uma marca ou nome comercial próprio e
                                                distintivo, que não seja confundível com a marca Mercado Livre e sua família de
                                                marcas “Mercado”.
                                            </p>
                                            <p class="pharagraphTerm"   tabindex="0" role="paragraph">
                                                É proibido usar nossos produtos ou serviços para fins
                                                ilegais, realizar qualquer tipo de engenharia reversa ou obras derivadas, usar
                                                ferramentas de busca ou extração de dados e conteúdo de nossa plataforma para
                                                reutilização e/ou criar bancos de dados próprios que incluam, no todo ou em parte,
                                                nosso conteúdo sem nossa expressa autorização. É também proibido o uso indevido, sem
                                                autorização e/ou contrário às normas vigentes e/ou que gere confusão ou implique uso
                                                difamatório e/ou que cause prejuízo, danos ou perdas ao Mercado Livre e/ou suas
                                                sociedades relacionadas. A utilização dos produtos e serviços do Mercado Livre
                                                também não implica a autorização para usar propriedade intelectual de terceiros que
                                                possa estar envolvida, cujo uso ficará sob exclusiva responsabilidade do
                                                usuário.&nbsp;<br>Caso uma Pessoa Usuária ou qualquer anúncio infrinja a Propriedade
                                                Intelectual do Mercado Livre ou de terceiros, o Mercado Livre poderá remover esse
                                                anúncio totalmente ou parcialmente, sancionar o usuário conforme previsto nestes
                                                Termos e Condições e exercer as ações extrajudiciais e/ou judiciais correspondentes.
                                            </p>
                                            <h2 class="termAndCondition" tabindex="0" role="heading">11- Indenidade</h2>
                                            <p class="pharagraphTerm"   tabindex="0" role="paragraph">
                                                A Pessoa Usuária manterá indene o Mercado Livre e suas
                                                sociedades relacionadas, assim como aqueles que a dirigem, sucedem, administram,
                                                representam e/ou trabalham nelas, perante qualquer reclamação administrativa ou
                                                judicial iniciada por outras Pessoas Usuárias, terceiros ou por qualquer entidade,
                                                em relação a suas atividades no Ecossistema MELI.
                                            </p>
                                            <p class="pharagraphTerm"   tabindex="0" role="paragraph">
                                                Em virtude dessa responsabilidade, eles poderão
                                                realizar compensações, retenções ou outras medidas necessárias para a reparação de
                                                perdas, danos e prejuízos, qualquer que seja sua natureza.
                                            </p>
                                            <h2 class="termAndCondition" tabindex="0" role="heading">12- Anexos</h2>
                                            <p class="pharagraphTerm"   tabindex="0" role="paragraph">
                                                Além desses Termos e Condições, cada serviço do
                                                Ecossistema MELI tem suas próprias regras de uso: &nbsp;
                                            </p>
                                            <ul class="pharagraphTerm"   tabindex="0" role="list">
                                                <li>
                                                    <a href="#23050" target="_self">Marketplace</a>
                                                </li>
                                                <li>
                                                    <a href="#22962" target="_self">Marketplace VIS</a>
                                                </li>
                                                <li>
                                                    <a href="#2900" target="_self">Mercado Pontos </a>
                                                </li>
                                                <li>
                                                    <a href="#1086" target="_self">Mercado Shops </a>
                                                </li>
                                                <li>
                                                    <a href="#299" target="_self">Mercado Pago </a>
                                                </li>
                                                <li>Mercado Envios:
                                                    <ul class=""   tabindex="0" role="list">
                                                        <li>
                                                            <a href="#Termos-e-condicoes-gerais-de-uso_1500" target="_blank" rel="noopener">
                                                                Serviço de Coleta e Agências Mercado Livre
                                                            </a>
                                                        </li>
                                                        <li>
                                                            <a href="#1004" target="_self">Dropshipping</a>
                                                        </li>
                                                    </ul>
                                                </li>
                                            </ul>
                                            <h2 class="termAndCondition" tabindex="0" role="heading">13- Jurisdição e lei aplicável</h2>
                                            <p class="pharagraphTerm"   tabindex="0" role="paragraph">
                                                Estes Termos e Condições são regidos pela legislação
                                                vigente. Qualquer controvérsia decorrente de sua aplicação, interpretação, execução
                                                ou validade será submetida ao Foro da Comarca de São Paulo-SP, salvo as reclamações
                                                apresentadas por Pessoas Usuárias que se enquadrem no conceito legal de
                                                consumidores, que poderão submeter tais reclamações ao foro de seu domicílio,
                                                conforme previsão do Código de Defesa do Consumidor.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <!-- <div class="andes-card andes-card--flat andes-card--default cx-peach__effectivity null andes-card--padding-default">
                                    <div name="scroll-to-element" class="cx-peach__effectivity__wrapper">
                                        <h3 class="cx-peach__effectivity__title termAndCondition" tabindex="0">
                                            As informações foram úteis?
                                        </h3>
                                        <div class="cx-peach__effectivity__buttons">
                                            <button type="button" class="andes-button btn yes andes-button--medium andes-button--quiet" data-testid="yes-btn">
                                                <span class="andes-button__content">Sim</span>
                                            </button>
                                            <button type="button" class="andes-button btn no andes-button--medium andes-button--quiet" data-testid="no-btn">
                                                <span class="andes-button__content">Não</span>
                                            </button>
                                        </div>
                                    </div>
                                </div> -->
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
</template>