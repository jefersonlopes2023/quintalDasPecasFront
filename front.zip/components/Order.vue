<template>
    <div class="ui-search-view-options__container">
        <div class="ui-search-styled-label screen-reader-only" role="heading" aria-level="2" id="results">
            Resultados
        </div>
        <div class="ui-search-view-options shops__view-options">
            <div class="ui-search-view-options__content">
                <div class="ui-search-view-options__group">
                    <div class="ui-search-view-options__title shops-custom-primary-font">Ordenar por<!-- --> </div>
                    <div class="ui-search-sort-filter shops__sort-filter">
                        <div class="andes-dropdown andes-dropdown--standalone ui-search-sort-filter__dropdown andes-dropdown--compact">
                            <div class="andes-floating-menu">
                                <button type="button" class="andes-dropdown__trigger" aria-label="Mais relevantes: Mais relevantes" aria-invalid="false" aria-expanded="false" aria-haspopup="listbox">
                                    <span class="andes-dropdown__display-values">
                                        Mais relevantes
                                    </span>
                                    <svg class="andes-dropdown__standalone-arrow" width="12" height="12" viewBox="0 0 12 12" aria-hidden="true">
                                        <path fill-opacity=".45" d="M6 7.057L9.352 3.705 10.148 4.5 6 8.648 1.852 4.5 2.648 3.705z">
                                        </path>
                                    </svg>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>