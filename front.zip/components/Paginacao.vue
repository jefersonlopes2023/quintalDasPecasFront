<template>
    <div class="ui-search-pagination shops__pagination-content">
        <ul class="ui-search-pagination andes-pagination shops__pagination" role="navigation">
            <li class="andes-pagination__button andes-pagination__button--current">
                <span class="andes-pagination__link">1</span>
            </li>
            <li class="andes-pagination__page-count">de
                <!-- -->40
            </li>
            <li class="andes-pagination__button andes-pagination__button--next shops__pagination-button">
                <a href="/lantern_Desde_51_NoIndex_True"
                    class="andes-pagination__link shops__pagination-link ui-search-link" title="Seguinte" role="button"
                    rel="nofollow">
                    <span class="andes-pagination__arrow-title">Seguinte</span>
                    <span class="andes-pagination__arrow"></span>
                </a>
            </li>
        </ul>
    </div>
</template>