<template>
    <Privacy></Privacy>
</template>
