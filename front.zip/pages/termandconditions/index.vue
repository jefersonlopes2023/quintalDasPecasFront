<template>
    <TermAndConditionsPage />
</template>