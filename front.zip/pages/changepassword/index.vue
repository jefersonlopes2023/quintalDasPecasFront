<template>
    <section data-testid="recommendations" class="recommendations" type="recommendations">
        <div class="row g-8  justify-content-center">
            <div class="col-lg-6 col-md-6 col-sm-6 col-6 ">
                <FormChangePassword />
            </div>
        </div>
    </section>
</template>