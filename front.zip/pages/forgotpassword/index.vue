<template>
    <FormForgotPassword />
</template>
