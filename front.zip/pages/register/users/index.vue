<template>
   <FormRegister></FormRegister>
</template>