<template>
  <FormRegisterPf></FormRegisterPf>
</template>