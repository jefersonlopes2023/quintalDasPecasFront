<template>
  <FormRegisterPj></FormRegisterPj>
</template>