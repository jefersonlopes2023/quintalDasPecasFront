<template>
    <contact></contact>
</template>