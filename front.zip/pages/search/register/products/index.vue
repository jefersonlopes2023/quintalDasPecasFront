<script setup>

</script>
<template>   
    <div class="container">
        <div class="row">
            <form class="row justify-content-lg-center g-4">
                <div class="row g-2 justify-content-lg-center">
                    <div class="card">
                     
                    </div>
                </div>
            </form>
        </div>       
    </div>
    <br>
</template>
