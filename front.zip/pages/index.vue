<template>
    <Vitrine />
</template>