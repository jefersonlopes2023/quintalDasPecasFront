<template>
    <br>
    <br>
    <div class="container"> 
        <form class="row justify-content-lg-center g-4">
            <PartialsBanner></PartialsBanner>
        </form>
    </div>
    <br>
</template>