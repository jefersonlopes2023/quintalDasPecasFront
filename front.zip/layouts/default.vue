<template>
      <NavHeader />
        <slot />  
        <Footer />
</template>